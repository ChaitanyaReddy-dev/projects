package sa.com.stc.plm.configclient;


import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

import java.sql.SQLException;

@Service
public class Boo implements Too {


    @Override
    public void boo1() throws SQLException {

        System.out.println("im in boo");
        throw new SQLException();
    }

}

 interface Too{
     void boo1() throws SQLException;
}
