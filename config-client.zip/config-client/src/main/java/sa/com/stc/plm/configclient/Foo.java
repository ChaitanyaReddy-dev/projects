package sa.com.stc.plm.configclient;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.retry.annotation.Recover;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.sql.SQLException;

@RefreshScope
@RestController
public class Foo {

    @Autowired
    Too too;

    @Autowired
    woo woo;

    @Value("${product.name}")
    String name;


    @GetMapping("/get")

    public void test() throws SQLException {

        test1();


    }

    private void test1() throws SQLException {
        String a = test2("ch");
    }

    private String test2(String a) throws SQLException {
        woo.woo1();
        return a;
    }


    @GetMapping("/name")
    public String get(){
       return name;
    }


}
