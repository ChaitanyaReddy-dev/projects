package sa.com.stc.plm.configclient;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

import java.sql.SQLException;

@Service
public class woo {

    @Autowired
    Too too;

    @Retryable(
            value = {SQLException.class},
            maxAttempts = 4,
            backoff = @Backoff(delay = 1000))
    public void woo1() throws SQLException {
        too.boo1();
    }
    @Recover
    public void recover(SQLException e) {
        System.out.println("inside recover");

    }
}
